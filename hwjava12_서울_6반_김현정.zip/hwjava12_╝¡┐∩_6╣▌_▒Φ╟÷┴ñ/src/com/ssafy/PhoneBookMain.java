package com.ssafy;

//클라이언트 부분 메인 클래스
public class PhoneBookMain {
	public static void main(String[] args) {
		ContactGUI gui = new ContactGUI();
	}
}
